# StudySphere International — Complete Website

Open `index.html` to preview the site.

Pages included:
Home, Study Destinations, Universities, Services, Scholarships, About Us, Blog, Contact Us, Apply Now.

Your uploaded StudySphere International logo is included in `assets/studysphere-logo.png`.

The forms are demo forms. Before launch, replace sample contact details, statistics, testimonials, team information and university partners, then connect forms to your email/CRM/WhatsApp/database.
